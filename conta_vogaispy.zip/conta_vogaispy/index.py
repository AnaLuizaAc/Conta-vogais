p = input("Digite uma palavra: ")

contador = 0

for letra in p:
    if letra in "aeiouAEIOU":
        contador += 1
    print("a palavra '{}' tem {} vogais.".format(p, contador))